# comp2068-lesson12-template-wed
<h1>Template for MEAN Stack SPA</h1>
<p>We will use this app as a template for Lesson 12 of COMP2068 Advanced Web Programming.  In this lesson, we will take our "MEN Stack" Team application and reuse parts of this to build a Single Page MEAN Stack Application.</p>


