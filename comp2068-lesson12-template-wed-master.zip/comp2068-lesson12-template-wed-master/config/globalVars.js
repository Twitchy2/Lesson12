/**
 * Created by RFreeman on 10/5/2016.
 */

// set up a global object to hold variables
// start with the db connection string
module.exports = {
    db: 'mongodb://localhost/comp2068',
    secret: 'It is take your grade 9 to work day'
    //db: 'mongodb://gcrfreeman2:pass@ds048319.mlab.com:48319/comp2068-wed'
};